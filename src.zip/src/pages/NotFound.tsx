export default function NotFound() {
  return <div className="container py-8">Page not found</div>
}
