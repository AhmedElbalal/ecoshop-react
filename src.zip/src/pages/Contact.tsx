export default function Contact() {
  return (
    <div className="container prose max-w-2xl py-8">
      <h1>Contact</h1>
      <p>Reach us anytime.</p>
    </div>
  )
}
